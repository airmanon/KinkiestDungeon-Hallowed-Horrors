"use strict";

//This file will be used to load in Blood Magic Spells

console.log("Access to file successful");

KinkyDungeonLearnableSpells.push({name: "ApprenticeBlood", tags: ["magic"], autoLearn: ["Bite"], hideLearned: true, hideUnlearnable: true, school: "Elements", manacost: 0, spellPointCost: 1, components: [], level:1, passive: true, type:"", onhit:"", time: 0, delay: 0, range: 0, lifetime: 0, power: 0, damage: "inert"});

KinkyDungeonLearnableSpells.push({name: "Bite", tags: ["earth", "struggle", "restore", "buff", "utility", "offense"], prerequisite: "ApprenticeBlood", sfx: "FireSpell", school: "Elements", manacost: 1, components: [], level:1, type:"passive", events: [
			//{type: "ElementalEffect", power: 2, damage: "crush", trigger: "playerAttack"},
			{trigger: "beforePlayerAttack", type: "BoostDamage", prereq: "damageType", kind: "melee", power: 2},
			//{trigger: "calcDisplayDamage", type: "BoostDamage", prereq: "damageType", kind: "melee", power: 2},
			//{type: "ModifyStruggle", mult: 1.5, power: 0.2, StruggleType: "Struggle", trigger: "beforeStruggleCalc", msg: "KinkyDungeonSpellStrengthStruggle"},
			{type: "restore", wp_instant: 2.5, scaleWithMaxWP: true},
		]});