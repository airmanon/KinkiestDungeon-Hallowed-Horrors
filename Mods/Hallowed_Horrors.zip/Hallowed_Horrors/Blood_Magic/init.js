'use strict';

//Adds in a page to the spellbook.
KinkyDungeonSpellPages.push("Blood");
addTextKey("KinkyDungeonSpellsPageBlood", "Blood Magic"); // TextKey format is KinkyDungeonSpellsPage<stringPushed>

//KDColumnLabels.push(["Verbal", "Arms", "Legs", "Passive"]);

//Need to define a restore type event in order for it to work.
KDEventMapSpell.playerAttack.restore = (e, spell, data) => {
	if (KinkyDungeonHasMana(KinkyDungeonGetManaCost(spell)) && (KinkyDungeonPlayerDamage.name == "Unarmed")) // Ada's suggestion to have it only activate when player's unarmed.
	{
		KinkyDungeonChangeMana(-KinkyDungeonGetManaCost(spell));
		KinkyDungeonChangeWill(KinkyDungeonPlayerDamage.dmg);
	}
};

KinkyDungeonLearnableSpells.push([
	["ApprenticeBlood"/*, "Seduce"*/],
	[/*"ArmSpell"*/],
	[/*"LegSpell"*/],
	["Bite"]
]);
// TextKey format is KinkyDungeonLearnableSpells<stringPushed>
addTextKey("KinkyDungeonLearnableSpellsApprenticeBlood", "Apprentice Blood");
addTextKey("KinkyDungeonLearnableSpellsBite", "Bite");
//addTextKey("KinkyDungeonLearnableSpellsSeduce", "Seduce");
//addTextKey("KinkyDungeonLearnableSpellsArmSpell", "ArmSpell");
//addTextKey("KinkyDungeonLearnableSpellsLegSpell", "LegSpell");

KinkyDungeonSpellList.Blood = [
	{name: "ApprenticeBlood", tags: ["magic"], autoLearn: ["Bite"], hideLearned: true, hideUnlearnable: true, school: "Blood", manacost: 0, spellPointCost: 1, components: [], level:1, passive: true, type:"", onhit:"", time: 0, delay: 0, range: 0, lifetime: 0, power: 0, damage: "inert"},
	{name: "Bite", tags: ["buff", "utility", "offense"], prerequisite: "ApprenticeBlood", sfx: "FireSpell", school: "Blood", manacost: 1, components: [], level:1, type:"passive", events: [
			{type: "restore", trigger: "playerAttack"}]}//,
			/*
			{name: "Seduce", tags: ["buff", "utility", "offense"], prerequisite: "ApprenticeBlood", sfx: "FireSpell", school: "Blood", manacost: 1, components: ["Verbal"], level:1, type:"passive", events: [
			{type: "convert", trigger: "PlayerAttack", wp_instant: 2.5, scaleWithMaxWP: true},]},
			*/
			/*
			{name: "ArmSpell", tags: ["buff", "utility", "offense"], prerequisite: "ApprenticeBlood", sfx: "FireSpell", school: "Blood", manacost: 1, components: ["Arms"], level:1, type:"passive", events: [
			{type: "restore", trigger: "bulletHitEnemy", wp_instant: 2.5, scaleWithMaxWP: true},]},
			*/
			/*
			{name: "LegSpell", tags: ["buff", "utility", "offense"], prerequisite: "ApprenticeBlood", sfx: "FireSpell", school: "Blood", manacost: 1, components: ["Legs"], level:1, type:"passive", events: [
			{type: "restore", trigger: "PlayerAttack", wp_instant: 2.5, scaleWithMaxWP: true},]}
			*/
			];

addTextKey("KinkyDungeonSpellsSchoolBlood", "Blood Magic"); // TextKey format is KinkyDungeonSpellsSchool<stringAfterSchool>

addTextKey("KinkyDungeonSpellApprenticeBlood", "Apprentice Blood"); // TextKey format is KinkyDungeonSpell<stringPushed>
addTextKey("KinkyDungeonSpellDescriptionApprenticeBlood", "Unlocks draining spells. Learn Bite."); // TextKey format is KinkyDungeonSpellDescription<stringPushed>

addTextKey("KinkyDungeonSpellBite", "Bite");
addTextKey("KinkyDungeonSpellDescriptionBite", "When active, uses mana to restore willpower with melee attacks");

/*
addTextKey("KinkyDungeonSpellSeduce", "Seduce");
addTextKey("KinkyDungeonSpellDescriptionSeduce", "Convince enemies to join your side.");

addTextKey("KinkyDungeonSpellArmSpell", "ArmSpell");
addTextKey("KinkyDungeonSpellDescriptionArmSpell", "ArmDescription");

addTextKey("KinkyDungeonSpellLegSpell", "LegSpell");
addTextKey("KinkyDungeonSpellDescriptionLegSpell", "LegDescription");
*/