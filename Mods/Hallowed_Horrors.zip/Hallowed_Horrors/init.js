"use strict";

/*
	This file will call the init.js files located in the folders inside
		the Hallowed_Horrors folder.
*/

var bloodMagic = require('./Blood_Magic/init');


//let bloodMagicFolder = Folder("./Blood_Magic");
//let bloodMagicFolder = Folder(current);
//let bloodMagicFile = bloodMagicFolder.getFiles("init.js");

//let bloodMagicFile = File("./Blood_Magic/init.js");
//bloodMagicFile.execute();